/* PDF-IA: imágenes a PDF sin descargar el motor pesado (PyMuPDF).
   Usa pdf-lib: JPG y PNG se incrustan tal cual; los demás formatos se pasan a JPG. */
import { PDFDocument } from 'pdf-lib';

async function aJpeg(file: Blob): Promise<Uint8Array> {
  const bmp = await createImageBitmap(file);
  const c = document.createElement('canvas');
  c.width = bmp.width;
  c.height = bmp.height;
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, c.width, c.height);
  ctx.drawImage(bmp, 0, 0);
  const blob: Blob = await new Promise((ok, mal) =>
    c.toBlob((b) => (b ? ok(b) : mal(new Error('No se pudo leer la imagen'))), 'image/jpeg', 0.92)
  );
  return new Uint8Array(await blob.arrayBuffer());
}

export async function imagenesAPdf(files: File[]): Promise<Blob> {
  const doc = await PDFDocument.create();
  for (const f of files) {
    const bytes = new Uint8Array(await f.arrayBuffer());
    const esJpg = bytes[0] === 0xff && bytes[1] === 0xd8;
    const esPng = bytes[0] === 0x89 && bytes[1] === 0x50;
    let img;
    try {
      img = esJpg ? await doc.embedJpg(bytes) : esPng ? await doc.embedPng(bytes) : await doc.embedJpg(await aJpeg(f));
    } catch {
      img = await doc.embedJpg(await aJpeg(f));
    }
    // 96 ppp → puntos PDF
    const w = img.width * 0.75;
    const h = img.height * 0.75;
    const page = doc.addPage([w, h]);
    page.drawImage(img, { x: 0, y: 0, width: w, height: h });
  }
  doc.setProducer('PDF-IA · SkyNet Genesis');
  doc.setCreator('PDF-IA · SkyNet Genesis (skynetgenesis.com)');
  const out = await doc.save();
  return new Blob([out], { type: 'application/pdf' });
}
