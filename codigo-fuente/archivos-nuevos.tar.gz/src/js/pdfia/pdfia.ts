/* PDF-IA · SkyNet Genesis
   Capa propia sobre BentoPDF (AGPL-3.0): marca, 3 documentos gratis,
   compra única con Bold, descargas dentro de Claude, pie y soporte.
   Todo se procesa en el celular: nada se sube a servidores. */

import { TRAD } from './traducciones';

const CFG = {
  version: '1.0.0',
  precio: 9900,
  gratis: 3,
  plan: 'pdf-ia:licencia',
  planPrueba: 'pdf-ia:prueba',
  app: 'pdf-ia',
  firmador: 'https://skynetgenesis.com/bold-firma.php',
  verificador: 'https://skynetgenesis.com/bold-verificar.php',
  volver: 'https://pdf-ia.skynetgenesis.com/',
  wa: 'https://wa.me/573044375758',
  repo: 'https://github.com/RL-rikardolondono/pdf-ia',
};
const PRODUCCION = /(^|\.)skynetgenesis\.com$/i.test(location.hostname);
const LOGO =
  '<svg viewBox="0 0 200 200" aria-hidden="true"><rect x="4" y="4" width="192" height="192" rx="46" fill="#1E3A4C"/><g stroke="#FFFFFF" stroke-linecap="round"><polygon points="100,42 150.2,71 150.2,129 100,158 49.8,129 49.8,71" fill="none" stroke-opacity=".35" stroke-width="4"/><path d="M100 100L100 42M100 100L150.2 71M100 100L150.2 129M100 100L100 158M100 100L49.8 129M100 100L49.8 71" stroke-width="6"/></g><g fill="#FFFFFF"><circle cx="150.2" cy="71" r="10"/><circle cx="150.2" cy="129" r="10"/><circle cx="100" cy="158" r="10"/><circle cx="49.8" cy="129" r="10"/><circle cx="49.8" cy="71" r="10"/></g><circle cx="100" cy="42" r="13" fill="#E0A21A"/><circle cx="100" cy="100" r="20" fill="#E0A21A"/></svg>';

/* ---------- almacenamiento (compartido con la página Escanear) ---------- */
const ls = {
  get<T>(k: string, d: T): T {
    try {
      const v = localStorage.getItem('pdfia.' + k);
      return v === null ? d : (JSON.parse(v) as T);
    } catch {
      return d;
    }
  },
  set(k: string, v: unknown) {
    try {
      localStorage.setItem('pdfia.' + k, JSON.stringify(v));
    } catch {
      /* sin almacenamiento */
    }
  },
  del(k: string) {
    try {
      localStorage.removeItem('pdfia.' + k);
    } catch {
      /* nada */
    }
  },
};
const uid = () =>
  Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
const fmt = (n: number) => '$' + n.toLocaleString('es-CO');
const espera = (ms: number) => new Promise((r) => setTimeout(r, ms));
const esc = (s: string) =>
  String(s).replace(
    /[&<>"']/g,
    (c) =>
      ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[
        c
      ] as string
  );

const licencia = () => ls.get<{ ref: string; fecha: number } | null>('licencia', null);
const usados = () => ls.get<string[]>('usados', []);
const quedan = () => Math.max(0, CFG.gratis - usados().length);
function dispositivo() {
  let d = ls.get<string>('dispositivo', '');
  if (!d) {
    d = 'pdf' + uid().replace(/[^a-z0-9]/gi, '').slice(0, 14);
    ls.set('dispositivo', d);
  }
  return d;
}

/* ---------- estilos de la capa ---------- */
const CSS = `
body.pia-limite #alert-modal{display:none!important}
.pia-chip{display:inline-flex;align-items:center;gap:6px;border:1px solid #DCE5EE;background:#E3F6F2;color:#0E8571;font:700 13px 'Public Sans',sans-serif;padding:8px 12px;border-radius:999px;cursor:pointer;white-space:nowrap}
.pia-chip.lic{background:#E8F1FA;color:#0B4F8A}
.pia-nav-der{margin-left:auto;display:flex;gap:8px;align-items:center}
.pia-wa{display:inline-flex;align-items:center;gap:6px;background:#1F8A4C;color:#fff !important;font:700 13px 'Public Sans',sans-serif;padding:8px 12px;border-radius:999px;text-decoration:none;white-space:nowrap}
@media(max-width:520px){.pia-wa span{display:none}.pia-chip{padding:7px 10px;font-size:12px}}
.pia-velo{position:fixed;inset:0;background:rgba(28,43,57,.55);display:none;align-items:center;justify-content:center;z-index:2147483000;padding:16px}
.pia-velo.ver{display:flex}
.pia-caja{background:#fff;color:#1C2B39;border-radius:18px;max-width:460px;width:100%;padding:24px;box-shadow:0 20px 60px rgba(11,79,138,.25);font-family:'Public Sans',sans-serif;max-height:92vh;overflow:auto}
.pia-caja h2{font:700 28px/1.1 'Barlow Condensed','Public Sans',sans-serif;color:#0B4F8A;margin:0 0 8px}
.pia-caja p{margin:0 0 12px;line-height:1.5;font-size:15px;color:#1C2B39}
.pia-caja .pia-precio{font:700 40px/1 'Barlow Condensed',sans-serif;color:#0E8571;margin:8px 0 2px}
.pia-caja ul{margin:8px 0 14px;padding-left:22px;line-height:1.6;font-size:15px;list-style:disc}.pia-hero .izq ul{list-style:disc}
.pia-btn{display:flex;width:100%;align-items:center;justify-content:center;gap:8px;min-height:48px;border-radius:12px;border:0;font:700 16px 'Public Sans',sans-serif;cursor:pointer;margin-top:10px;text-decoration:none}
.pia-btn.prim{background:#14A38B;color:#fff}.pia-btn.prim:hover{background:#0E8571}
.pia-btn.sec{background:#fff;color:#0B4F8A;border:1px solid #DCE5EE}
.pia-btn.wa{background:#1F8A4C;color:#fff}
.pia-in{width:100%;min-height:46px;border:1px solid #DCE5EE;border-radius:10px;padding:10px 12px;font:16px 'Public Sans',sans-serif;color:#1C2B39;background:#fff;color-scheme:light}
.pia-nota{font-size:13px !important;color:#5D6B78 !important}
.pia-toast{position:fixed;left:50%;bottom:22px;transform:translateX(-50%) translateY(30px);background:#0B4F8A;color:#fff;font:700 16px/1.4 'Public Sans',sans-serif;padding:14px 20px;border-radius:14px;max-width:min(560px,92vw);box-shadow:0 10px 30px rgba(11,79,138,.3);opacity:0;pointer-events:none;transition:.25s;z-index:2147483001;text-align:center}
.pia-toast.ver{opacity:1;transform:translateX(-50%) translateY(0)}
.pia-pie{margin:48px auto 0;padding:26px 16px 34px;border-top:1px solid #DCE5EE;text-align:center;font:14px/1.7 'Public Sans',sans-serif;color:#5D6B78;background:#fff}
.pia-pie a{color:#0B4F8A;font-weight:600}
.pia-pie .pia-marca{display:inline-flex;align-items:center;gap:8px;font:700 18px 'Barlow Condensed',sans-serif;color:#0B4F8A}
.pia-pie svg,.pia-caja svg.logo{width:28px;height:28px}
.pia-hero{max-width:980px;margin:0 auto 26px;display:grid;grid-template-columns:minmax(0,1.4fr) minmax(0,1fr);gap:18px;align-items:stretch}
.pia-hero .izq{background:linear-gradient(135deg,#0B4F8A,#1867B0);color:#fff;border-radius:20px;padding:26px 24px}
.pia-hero .izq h1{color:#fff !important;font:700 clamp(30px,5vw,44px)/1.05 'Barlow Condensed',sans-serif;margin:0 0 10px;text-align:left}
.pia-hero .izq p{color:#E8F1FA !important;font-size:16px;line-height:1.5;margin:0 0 14px;text-align:left}
.pia-hero .izq ul{margin:0;padding-left:18px;color:#fff;font-size:15px;line-height:1.7;text-align:left}
.pia-hero .der{background:#fff;border:1px solid #DCE5EE;border-radius:20px;padding:20px;display:flex;flex-direction:column;gap:10px;justify-content:center}
.pia-hero .der a{display:flex;align-items:center;gap:12px;padding:14px;border-radius:14px;text-decoration:none;font:700 16px 'Public Sans',sans-serif;color:#1C2B39;border:1px solid #DCE5EE;background:#F4F8FB}
.pia-hero .der a.top{background:#14A38B;color:#fff;border-color:#14A38B;font-size:18px}
.pia-hero .der a i{font-size:26px}
@media(max-width:760px){.pia-hero{grid-template-columns:minmax(0,1fr)}}
`;

function inyectarEstilos() {
  if (document.getElementById('pia-css')) return;
  const st = document.createElement('style');
  st.id = 'pia-css';
  st.textContent = CSS;
  document.head.appendChild(st);
}

/* ---------- avisos ---------- */
let toastT: number | undefined;
function toast(msg: string, ms = 6000) {
  let t = document.getElementById('pia-toast');
  if (!t) {
    t = document.createElement('div');
    t.id = 'pia-toast';
    t.className = 'pia-toast';
    t.setAttribute('role', 'status');
    document.body.appendChild(t);
  }
  t.textContent = msg;
  t.classList.add('ver');
  window.clearTimeout(toastT);
  toastT = window.setTimeout(() => t!.classList.remove('ver'), ms);
}

/* ---------- ventana de compra ---------- */
function velo(): HTMLElement {
  let v = document.getElementById('pia-velo');
  if (!v) {
    v = document.createElement('div');
    v.id = 'pia-velo';
    v.className = 'pia-velo';
    v.setAttribute('role', 'dialog');
    v.setAttribute('aria-modal', 'true');
    v.innerHTML = '<div class="pia-caja" id="pia-caja"></div>';
    document.body.appendChild(v);
  }
  return v;
}
function cerrar() {
  velo().classList.remove('ver');
  document.body.classList.remove('pia-limite');
}
let pendiente: (() => void) | null = null;

export function abrirCompra(motivo?: 'limite') {
  const v = velo();
  const c = v.querySelector('#pia-caja') as HTMLElement;
  const lic = licencia();
  if (lic) {
    c.innerHTML = `<h2>PDF-IA completa ✓</h2>
      <p>Esta es su versión completa: documentos ilimitados en este celular o computador, con todas las herramientas.</p>
      <p class="pia-nota">Código de su compra: <b>${esc(lic.ref)}</b>. Guárdelo: con él recupera la compra si borra los datos del navegador.</p>
      <a class="pia-btn wa" href="${CFG.wa}?text=${encodeURIComponent('Hola, necesito ayuda con PDF-IA')}" target="_blank" rel="noopener">Soporte por WhatsApp</a>
      <button class="pia-btn sec" type="button" data-pia="cerrar">← Volver</button>`;
  } else {
    const q = quedan();
    c.innerHTML = `<h2>${motivo === 'limite' ? 'Ya usó sus ' + CFG.gratis + ' documentos gratis' : 'PDF-IA completa'}</h2>
      <p>${motivo === 'limite' ? 'Su documento está listo. Para descargarlo y seguir usando PDF-IA sin límite, active la versión completa.' : q > 0 ? 'Le quedan <b>' + q + ' de ' + CFG.gratis + '</b> documentos gratis. Con la versión completa no tiene límite.' : 'Ya usó sus documentos gratis. Active la versión completa para seguir.'}</p>
      <div class="pia-precio">${fmt(CFG.precio)}</div>
      <p class="pia-nota" style="margin-bottom:6px">Pago único. Sin mensualidades.</p>
      <ul><li>Documentos ilimitados</li><li>Escanear, convertir, unir, editar, firmar y proteger</li><li>Sus archivos nunca salen de su equipo</li></ul>
      <button class="pia-btn prim" type="button" data-pia="pagar">Comprar por ${fmt(CFG.precio)}</button>
      <p class="pia-nota" style="text-align:center;margin-top:6px">Pago seguro: tarjeta débito o crédito, PSE, Nequi o llave Bre-B.</p>
      <details style="margin-top:8px"><summary style="cursor:pointer;font-weight:700;color:#0B4F8A">Ya compré: recuperar mi compra</summary>
        <p class="pia-nota" style="margin-top:8px">Escriba el código de compra que le mostró el pago.</p>
        <input class="pia-in" id="pia-cod" autocomplete="off" placeholder="Código de la compra">
        <button class="pia-btn sec" type="button" data-pia="recuperar">Recuperar mi compra</button>
      </details>
      <a class="pia-btn wa" href="${CFG.wa}?text=${encodeURIComponent('Hola, quiero información sobre PDF-IA')}" target="_blank" rel="noopener">Hablar por WhatsApp</a>
      <button class="pia-btn sec" type="button" data-pia="cerrar">${motivo === 'limite' ? 'Ahora no' : '← Volver'}</button>`;
  }
  // mientras se pide la compra no se muestra el «listo» de la herramienta (el archivo aún no se ha entregado)
  if (motivo === 'limite') document.body.classList.add('pia-limite');
  v.classList.add('ver');
}
(window as unknown as { pdfiaComprar: typeof abrirCompra }).pdfiaComprar = abrirCompra;

function activar(ref: string) {
  ls.set('licencia', { ref, fecha: Date.now() });
  pintarChip();
  cerrar();
  const p = pendiente;
  toast(
    p
      ? '¡Versión completa activada! Su documento se está descargando.'
      : '¡Versión completa activada! Ya puede usar PDF-IA sin límite. Si estaba haciendo un documento, vuelva a procesarlo.',
    8000
  );
  pendiente = null;
  if (p) setTimeout(p, 400);
}

/* Diálogo propio (alert/confirm no funcionan dentro de Claude) */
function pregunta(txt: string, si: string, no = 'Cancelar'): Promise<boolean> {
  return new Promise((res) => {
    const c = velo().querySelector('#pia-caja') as HTMLElement;
    c.innerHTML = `<h2>Demostración</h2><p style="white-space:pre-line">${esc(txt)}</p>
      <button class="pia-btn prim" type="button" id="pia-si">${esc(si)}</button>
      <button class="pia-btn sec" type="button" id="pia-no">${esc(no)}</button>`;
    velo().classList.add('ver');
    (c.querySelector('#pia-si') as HTMLElement).onclick = () => res(true);
    (c.querySelector('#pia-no') as HTMLElement).onclick = () => {
      cerrar();
      res(false);
    };
  });
}

declare global {
  interface Window {
    BoldCheckout?: new (o: Record<string, string>) => { open: () => void };
    claude?: { use: (n: string) => Promise<unknown> };
  }
}

const PAGINA_AISLADA = /\/(word|excel|powerpoint|odt|ods|odp|odg|rtf|pub|vsd|wpd|wps|pages)-to-pdf\.html$/.test(location.pathname);

async function pagar() {
  if (PAGINA_AISLADA && PRODUCCION) {
    // En las páginas de conversión de Office la ventana de pago no puede abrirse: se paga desde el inicio
    location.href = import.meta.env.BASE_URL + 'index.html#comprar';
    return;
  }
  if (!PRODUCCION) {
    const ok = await pregunta(
      `Aquí se abriría el pago seguro por ${fmt(CFG.precio)} (pago único).\n¿Simular que el pago salió aprobado?`,
      'Simular pago aprobado'
    );
    if (ok) activar('DEMO-' + uid().toUpperCase());
    return;
  }
  if (!navigator.onLine) {
    toast('Necesita internet para comprar. Conéctese e intente de nuevo.');
    return;
  }
  toast('Abriendo el pago seguro…', 4000);
  try {
    const plan = location.hash === '#prueba-bold' ? CFG.planPrueba : CFG.plan;
    const u = `${CFG.firmador}?plan=${encodeURIComponent(plan)}&empresa=${encodeURIComponent(dispositivo())}&meses=1&volver=${encodeURIComponent(CFG.volver)}`;
    const r = await fetch(u, { cache: 'no-store' });
    const j = await r.json();
    if (!j || j.ok === false) throw new Error('firmador: ' + (j && j.error));
    const orden = j.orderId || j.order_id || j.orden;
    const llave = j.apiKey || j.api_key;
    const firma = j.signature || j.integritySignature || j.integrity_signature;
    if (!orden || !llave || !firma) throw new Error('respuesta incompleta');
    ls.set('pedido', { orden, fecha: Date.now() });
    if (!window.BoldCheckout) {
      await new Promise((ok, mal) => {
        const s = document.createElement('script');
        s.src = 'https://checkout.bold.co/library/boldPaymentButton.js';
        s.onload = ok;
        s.onerror = mal;
        document.head.appendChild(s);
      });
      for (let i = 0; i < 20 && !window.BoldCheckout; i++) await espera(150);
    }
    const pago = new window.BoldCheckout!({
      orderId: orden,
      currency: j.currency || 'COP',
      amount: String(j.amount || CFG.precio),
      apiKey: llave,
      integritySignature: firma,
      description: j.description || 'PDF-IA - Version completa (pago unico)',
      redirectionUrl: j.redirectionUrl || CFG.volver,
    });
    pago.open();
  } catch (e) {
    console.error(e);
    toast('No se pudo abrir el pago en este momento. Intente de nuevo o escríbanos por WhatsApp.', 8000);
  }
}

async function verificar(ref: string): Promise<string | null> {
  for (const clave of ['ref', 'pago']) {
    try {
      const r = await fetch(`${CFG.verificador}?${clave}=${encodeURIComponent(ref)}&app=${CFG.app}`, { cache: 'no-store' });
      if (!r.ok) continue;
      const j = await r.json();
      const o = j.orden || j.order || j.data || j;
      const plan = o.plan || '';
      const est = String(o.estado || o.status || '').toLowerCase();
      const ok =
        j.ok !== false &&
        (!plan || String(plan).indexOf('pdf-ia') === 0) &&
        (!est || /aprob|approved|pagad|aplicad|ok/.test(est));
      if (ok) return o.orden || o.order_id || o.referencia || ref;
    } catch {
      /* siguiente */
    }
  }
  return null;
}
async function recuperar(codigo: string) {
  codigo = (codigo || '').trim();
  if (codigo.length < 6) return toast('Escriba el código completo de la compra.');
  if (!PRODUCCION) return toast('En la demostración no hay compras reales para recuperar.');
  toast('Buscando su compra…', 4000);
  const ref = await verificar(codigo);
  if (ref) activar(ref);
  else toast('No encontramos una compra aprobada con ese código. Revíselo o escríbanos por WhatsApp.', 8000);
}
async function revisarRegresoBold() {
  const q = new URLSearchParams(location.search);
  const orden = q.get('bold-order-id');
  const estado = (q.get('bold-tx-status') || '').toLowerCase();
  if (!orden) return;
  try {
    history.replaceState(null, '', location.pathname);
  } catch {
    /* nada */
  }
  if (estado && estado !== 'approved') {
    toast('El pago no se completó. No se cobró nada; puede intentarlo de nuevo.', 8000);
    return;
  }
  toast('Confirmando su pago…', 5000);
  let ref: string | null = null;
  for (let i = 0; i < 6 && !ref; i++) {
    ref = await verificar(orden);
    if (!ref) await espera(4000);
  }
  if (ref) {
    ls.del('pedido');
    activar(ref);
  } else
    toast('El pago aún no se confirma. Espere un minuto y use «Ya compré: recuperar mi compra» con el código ' + orden + '.', 10000);
}

/* ---------- control de descargas: 3 gratis, luego compra ---------- */
let ultimoConteo = 0;
function permitirDescarga(): boolean {
  if (licencia()) return true;
  const ahora = Date.now();
  // Varias descargas seguidas del mismo trabajo (por ejemplo, varias imágenes) cuentan como un solo documento
  if (ahora - ultimoConteo < 8000) return true;
  if (quedan() <= 0) return false;
  const u = usados();
  u.push(uid());
  ls.set('usados', u);
  ultimoConteo = ahora;
  pintarChip();
  const q = quedan();
  setTimeout(
    () =>
      toast(q > 0 ? `Listo. Le ${q === 1 ? 'queda 1 documento gratis' : 'quedan ' + q + ' documentos gratis'}.` : 'Listo. Este fue su último documento gratis.', 6000),
    600
  );
  return true;
}

let descargasClaude: { save: (o: { filename: string; data: Blob }) => Promise<unknown> } | null = null;
const clickOriginal = HTMLAnchorElement.prototype.click;
const revocarOriginal = URL.revokeObjectURL.bind(URL);
// Algunas herramientas liberan el archivo justo después de pedir la descarga; lo conservamos un minuto
URL.revokeObjectURL = (u: string) => {
  setTimeout(() => revocarOriginal(u), 60000);
};

async function guardarEnClaude(href: string, nombre: string) {
  try {
    const blob = await (await fetch(href)).blob();
    await descargasClaude!.save({ filename: nombre || 'documento.pdf', data: blob });
    toast('Archivo entregado. Revise su carpeta de descargas.', 6000);
  } catch (e) {
    const code = (e as { code?: string })?.code;
    if (code === 'declined') toast('Descarga cancelada.', 4000);
    else if (code === 'rejected_extension') toast('Este tipo de archivo no se puede descargar dentro de la vista de prueba de Claude.', 8000);
    else toast('No se pudo descargar aquí. Intente de nuevo.', 6000);
  }
}

/* Nombres de archivo de salida en español */
const NOMBRES: Record<string, string> = {
  'document.pdf': 'documento.pdf', 'merged.pdf': 'unido.pdf', 'from_jpgs.pdf': 'fotos-a-pdf.pdf',
  'images_to_pdf.pdf': 'imagenes-a-pdf.pdf', 'from_webps.pdf': 'imagenes-a-pdf.pdf', 'from_tiff.pdf': 'tiff-a-pdf.pdf',
  'from_svgs.pdf': 'svg-a-pdf.pdf', 'from_heic.pdf': 'fotos-a-pdf.pdf', 'from_bmps.pdf': 'imagenes-a-pdf.pdf',
  'text_to_pdf.pdf': 'texto-a-pdf.pdf', 'markdown-document.pdf': 'documento.pdf', 'psd_to_pdf.pdf': 'psd-a-pdf.pdf',
  'split-document.pdf': 'documento-dividido.pdf', 'standard_crop.pdf': 'recortado.pdf', 'flattened_crop.pdf': 'recortado.pdf',
  'first.pdf': 'primera-parte.pdf', 'second.pdf': 'segunda-parte.pdf', 'ocr-text.txt': 'texto-reconocido.txt',
  'split-pages.zip': 'paginas-separadas.zip', 'split-n-times.zip': 'partes.zip', 'split-by-bookmarks.zip': 'partes-por-marcadores.zip',
  'word-converted.zip': 'word-convertidos.zip', 'excel-converted.zip': 'excel-convertidos.zip', 'powerpoint-converted.zip': 'powerpoint-convertidos.zip',
  'odt-converted.zip': 'odt-convertidos.zip', 'rtf-converted.zip': 'rtf-convertidos.zip', 'csv-converted.zip': 'csv-convertidos.zip',
  'emails-converted.zip': 'correos-convertidos.zip', 'converted-documents.zip': 'documentos-convertidos.zip', 'compressed-pdfs.zip': 'pdf-comprimidos.zip',
  'decrypted-pdfs.zip': 'pdf-desbloqueados.zip', 'flattened_pdfs.zip': 'pdf-aplanados.zip', 'repaired_pdfs.zip': 'pdf-reparados.zip',
  'reversed_pdfs.zip': 'pdf-invertidos.zip', 'rasterized-pdfs.zip': 'pdf-rasterizados.zip', 'linearized-pdfs.zip': 'pdf-optimizados-web.zip',
  'outlined_pdfs.zip': 'pdf-texto-en-curvas.zip', 'pdfa-converted.zip': 'pdfa-convertidos.zip', 'pdfs_archive.zip': 'pdfs.zip',
  'extracted-images.zip': 'imagenes-extraidas.zip', 'extracted-attachments.zip': 'adjuntos-extraidos.zip', 'pdf-to-text.zip': 'pdf-a-texto.zip',
  'pdf_to_svg.zip': 'pdf-a-svg.zip', 'page-dimensions.csv': 'tamanos-de-pagina.csv',
};
function nombreEspanol(a: HTMLAnchorElement) {
  const n = a.getAttribute('download');
  if (n && NOMBRES[n]) a.setAttribute('download', NOMBRES[n]);
}

/* Referencia de SkyNet Genesis en las propiedades de cada PDF que entrega la app (directiva de documentos) */
const SIN_MARCA = /\/(digital-sign-pdf|pdf-to-pdfa|linearize-pdf|protect-pdf|encrypt-pdf|change-permissions)\.html$/;
async function marcarPdf(href: string): Promise<string | null> {
  try {
    const blob = await (await fetch(href)).blob();
    if (blob.size > 40 * 1024 * 1024) return null;
    const { PDFDocument } = await import('pdf-lib');
    const doc = await PDFDocument.load(await blob.arrayBuffer(), { updateMetadata: false });
    doc.setCreator('PDF-IA · SkyNet Genesis · contacto@skynetgenesis.com · WhatsApp 3044375758');
    doc.setProducer('PDF-IA (skynetgenesis.com)');
    const bytes = await doc.save();
    return URL.createObjectURL(new Blob([new Uint8Array(bytes)], { type: 'application/pdf' }));
  } catch {
    return null; // cifrado o que pdf-lib no abre: se entrega tal cual
  }
}

function manejarDescarga(a: HTMLAnchorElement): boolean {
  // true = ya lo manejamos (no seguir con la descarga normal)
  const href = a.href || '';
  if (!a.hasAttribute('download') || !/^(blob:|data:)/.test(href)) return false;
  nombreEspanol(a);
  if (!a.dataset.piaMarcado && /\.pdf$/i.test(a.getAttribute('download') || '') && !SIN_MARCA.test(location.pathname)) {
    const a2 = a.cloneNode(false) as HTMLAnchorElement;
    a2.dataset.piaMarcado = '1';
    marcarPdf(href).then((nuevo) => {
      if (nuevo) a2.href = nuevo;
      if (!manejarDescarga(a2)) {
        document.body.appendChild(a2);
        clickOriginal.call(a2);
        a2.remove();
      }
    });
    return true;
  }
  const nombre = a.getAttribute('download') || 'documento.pdf';
  if (!permitirDescarga()) {
    pendiente = () => {
      if (descargasClaude) guardarEnClaude(href, nombre);
      else clickOriginal.call(a);
    };
    abrirCompra('limite');
    return true;
  }
  if (descargasClaude) {
    guardarEnClaude(href, nombre);
    return true;
  }
  return false;
}

HTMLAnchorElement.prototype.click = function (this: HTMLAnchorElement) {
  if (manejarDescarga(this)) return;
  return clickOriginal.call(this);
};
document.addEventListener(
  'click',
  (ev) => {
    const t = ev.target as HTMLElement | null;
    const a = t && (t.closest ? (t.closest('a[download]') as HTMLAnchorElement | null) : null);
    if (!a || !ev.isTrusted) return;
    if (manejarDescarga(a)) {
      ev.preventDefault();
      ev.stopPropagation();
    }
  },
  true
);
// Otras formas de descargar (saveAs y similares) también pasan por un enlace con «download»

/* ---------- barra, portada y pie ---------- */
function pintarChip() {
  const ch = document.getElementById('pia-chip');
  if (!ch) return;
  if (licencia()) {
    ch.textContent = 'Completa ✓';
    ch.classList.add('lic');
  } else {
    const q = quedan();
    ch.textContent = q === 1 ? '1 gratis' : q + ' gratis';
    ch.classList.remove('lic');
  }
}

function montarBarra() {
  const nav = document.querySelector('nav');
  const fila = nav?.querySelector('.flex.justify-start, .flex.justify-between, .flex') as HTMLElement | null;
  if (!fila || document.getElementById('pia-chip')) return;
  const der = document.createElement('div');
  der.className = 'pia-nav-der';
  der.innerHTML = `<button class="pia-chip" id="pia-chip" type="button" title="Documentos gratis y versión completa">3 gratis</button>
    <a class="pia-wa" href="${CFG.wa}?text=${encodeURIComponent('Hola, necesito ayuda con PDF-IA')}" target="_blank" rel="noopener" title="Soporte por WhatsApp">💬 <span>Soporte</span></a>`;
  fila.style.width = '100%';
  fila.appendChild(der);
  (der.querySelector('#pia-chip') as HTMLElement).onclick = () => abrirCompra();
  pintarChip();
}

function montarPortada() {
  const header = document.getElementById('tools-header');
  if (!header || document.getElementById('pia-hero')) return;
  const base = import.meta.env.BASE_URL;
  const hero = document.createElement('section');
  hero.id = 'pia-hero';
  hero.className = 'pia-hero';
  hero.innerHTML = `<div class="izq">
      <h1>Todo lo que necesita hacer con un PDF, en su celular</h1>
      <p>Escanee papeles con la cámara, convierta fotos y Word a PDF, una, edite, firme y proteja sus documentos. Sin subir nada a internet.</p>
      <ul><li>Más de 100 herramientas en una sola app</li><li>${CFG.gratis} documentos gratis para probarla</li><li>Versión completa: ${fmt(CFG.precio)}, pago único</li></ul>
    </div>
    <div class="der">
      <a class="top" href="${base}escanear/index.html"><i class="ph ph-camera"></i> Escanear un documento</a>
      ${VISTA_CLAUDE ? `<a href="${base}compress-pdf.html"><i class="ph ph-arrows-in"></i> Comprimir PDF</a>` : `<a href="${base}word-to-pdf.html"><i class="ph ph-file-doc"></i> Word a PDF</a>`}
      <a href="${base}merge-pdf.html"><i class="ph ph-browsers"></i> Unir varios PDF</a>
      <a href="${base}sign-pdf.html"><i class="ph ph-pen-nib"></i> Firmar un PDF</a>
    </div>`;
  header.innerHTML =
    '<h2 class="text-2xl md:text-3xl font-bold mb-2" style="color:#0B4F8A">Todas las herramientas</h2><p class="text-gray-400">Busque lo que necesita o recorra las categorías.</p>';
  header.parentElement!.insertBefore(hero, header);
}

function montarPie() {
  if (document.getElementById('pia-pie')) return;
  // Ocultar el pie original de la base
  document.querySelectorAll('footer').forEach((f) => ((f as HTMLElement).style.display = 'none'));
  const pie = document.createElement('footer');
  pie.id = 'pia-pie';
  pie.className = 'pia-pie';
  pie.innerHTML = `<div class="pia-marca">${LOGO} PDF-IA · SkyNet Genesis</div><br>
    Soporte: <a href="mailto:contacto@skynetgenesis.com">contacto@skynetgenesis.com</a> · <a href="${CFG.wa}" target="_blank" rel="noopener">WhatsApp 304 437 5758</a> · <a href="https://skynetgenesis.com" target="_blank" rel="noopener">skynetgenesis.com</a><br>
    Sus archivos se procesan solo en su equipo: PDF-IA no los sube a ningún servidor.<br>
    <span style="font-size:12px">Hecha con software libre: basada en BentoPDF (AGPL-3.0). <a href="${CFG.repo}" target="_blank" rel="noopener">Código fuente</a> · versión ${CFG.version}</span>`;
  document.body.appendChild(pie);
}

/* Service worker: funciona sin internet y habilita la conversión de Word, Excel y PowerPoint */
function prepararServiceWorker() {
  if (!('serviceWorker' in navigator)) return;
  const permitido = window.isSecureContext;
  if (!permitido) return;
  navigator.serviceWorker
    .register(import.meta.env.BASE_URL + 'sw.js')
    .then(() => {
      if (PAGINA_AISLADA && !window.crossOriginIsolated) {
        let ya = false;
        try {
          ya = sessionStorage.getItem('pdfia.recargaCOI') === location.pathname;
        } catch {
          /* nada */
        }
        if (!ya) {
          try {
            sessionStorage.setItem('pdfia.recargaCOI', location.pathname);
          } catch {
            /* nada */
          }
          const recargar = () => location.reload();
          if (navigator.serviceWorker.controller) recargar();
          else navigator.serviceWorker.addEventListener('controllerchange', recargar, { once: true });
        }
      }
    })
    .catch(() => {
      /* sin service worker (por ejemplo, dentro de Claude) */
    });
}

function avisoOffice() {
  /* sin avisos visibles: en Claude estas herramientas no se muestran */
}

/* ---------- traducción de textos que la base dejó en inglés ---------- */
const NO_TRADUCIR = '.textLayer, [contenteditable], .pdfViewer .page, #stage, .ec-page, script, style, textarea, code, pre';
function traducirNodo(raiz: Node) {
  const doc = raiz.ownerDocument || (raiz as Document);
  const w = doc.createTreeWalker(raiz, NodeFilter.SHOW_TEXT);
  let n: Node | null;
  while ((n = w.nextNode())) {
    const v = n.nodeValue || '';
    const t = v.replace(/\s+/g, ' ').trim();
    if (!t || t.length > 600) continue;
    const tr = TRAD[t];
    if (!tr) continue;
    const el = n.parentElement;
    if (!el || el.closest(NO_TRADUCIR)) continue;
    n.nodeValue = v.replace(/^(\s*)[\s\S]*?(\s*)$/, `$1${tr}$2`);
  }
  if ((raiz as Element).querySelectorAll) {
    (raiz as Element).querySelectorAll('[title],[placeholder],[aria-label]').forEach((e) => {
      for (const a of ['title', 'placeholder', 'aria-label']) {
        const v = e.getAttribute(a);
        if (v) {
          const tr = TRAD[v.replace(/\s+/g, ' ').trim()];
          if (tr) e.setAttribute(a, tr);
        }
      }
    });
  }
}
function observarTraduccion(doc: Document) {
  if (!doc.body || (doc as unknown as { __piaTrad?: boolean }).__piaTrad) return;
  (doc as unknown as { __piaTrad?: boolean }).__piaTrad = true;
  traducirNodo(doc.body);
  let pend = false;
  const obs = new MutationObserver((muts) => {
    if (pend) return;
    pend = true;
    requestAnimationFrame(() => {
      pend = false;
      for (const m of muts) {
        if (m.type === 'characterData' && m.target.parentNode) traducirNodo(m.target.parentNode);
        m.addedNodes.forEach((nd) => {
          if (nd.nodeType === 1) traducirNodo(nd);
          else if (nd.nodeType === 3 && nd.parentNode) traducirNodo(nd.parentNode);
        });
      }
      revisarIframes(doc);
    });
  });
  obs.observe(doc.body, { childList: true, subtree: true, characterData: true });
  revisarIframes(doc);
}
function revisarIframes(doc: Document) {
  doc.querySelectorAll('iframe').forEach((f) => {
    const ifr = f as HTMLIFrameElement;
    const intentar = () => {
      try {
        const d = ifr.contentDocument;
        if (d && d.body) observarTraduccion(d);
      } catch {
        /* iframe de otro sitio */
      }
    };
    if (!(ifr as unknown as { __piaIfr?: boolean }).__piaIfr) {
      (ifr as unknown as { __piaIfr?: boolean }).__piaIfr = true;
      ifr.addEventListener('load', intentar);
    }
    intentar();
  });
}

/* Vista de prueba en Claude: solo se incluye parte de las herramientas (límite de archivos) */
function filtrarHerramientasPrueba() {
  const lista = (window as unknown as { PDFIA_PAGINAS?: string[] }).PDFIA_PAGINAS;
  if (!lista) return;
  const permitidas = new Set(lista);
  const aplicar = () => {
    document.querySelectorAll('.tool-tile').forEach((t) => {
      const a = t.querySelector('a[href]') as HTMLAnchorElement | null;
      if (!a) return;
      const archivo = (a.getAttribute('href') || '').replace(/^\.?\//, '').split('#')[0];
      if (!permitidas.has(archivo)) (t as HTMLElement).style.display = 'none';
    });
    document.querySelectorAll('.category-group').forEach((g) => {
      const visibles = Array.from(g.querySelectorAll('.tool-tile')).some((t) => (t as HTMLElement).style.display !== 'none');
      (g as HTMLElement).style.display = visibles ? '' : 'none';
    });
  };
  aplicar();
  new MutationObserver(aplicar).observe(document.body, { childList: true, subtree: true });
  if (!document.getElementById('pia-aviso-prueba') && document.getElementById('pia-hero')) {
    const d = document.createElement('div');
    d.id = 'pia-aviso-prueba';
    d.style.cssText = 'max-width:980px;margin:0 auto 18px;padding:12px 16px;border-radius:14px;background:#E8F1FA;border:1px solid #C5D3E0;color:#0B4F8A;font:600 14px/1.5 Public Sans,sans-serif';
    d.textContent = 'Vista de prueba: aquí están las herramientas principales. La app publicada trae más de 100.';
    const hero = document.getElementById('pia-hero')!;
    hero.parentElement!.insertBefore(d, hero.nextSibling);
  }
}

/* Firmar PDF: guía visible de dónde se firma */
function guiaFirma() {
  const ed = document.getElementById('signature-editor');
  const lienzo = document.getElementById('canvas-container-sign');
  if (!ed || !lienzo || document.getElementById('pia-guia-firma')) return;
  const d = document.createElement('div');
  d.id = 'pia-guia-firma';
  d.style.cssText = 'margin:0 0 14px;padding:14px 16px;border-radius:14px;background:#E3F6F2;border:1px solid #14A38B;color:#1C2B39;font:15px/1.5 Public Sans,sans-serif';
  d.innerHTML = '<b style="font:700 18px Barlow Condensed,sans-serif;color:#0E8571">Cómo firmar en 3 pasos</b>' +
    '<ol style="margin:6px 0 0 20px;padding:0;list-style:decimal">' +
    '<li>En la barra gris del documento, toque el botón de firma <b>✍ (Añadir firma)</b> y luego <b>«+ Añadir nueva firma»</b>.</li>' +
    '<li>Escriba su nombre, dibújela con el dedo o cargue una foto de su firma, y pulse <b>Añadir</b>.</li>' +
    '<li>Toque sobre la hoja donde quiere que quede, ajústela, y al final pulse <b>«Guardar y descargar el PDF firmado»</b>.</li></ol>';
  lienzo.parentElement!.insertBefore(d, lienzo);
}

function iniciar() {
  inyectarEstilos();
  setTimeout(guiaFirma, 0);
  // Mensajes de error técnicos (en inglés o con nombres de motores) → mensaje claro en español
  {
    const msg = document.getElementById('alert-message');
    if (msg) {
      const limpiar = () => {
        const t = msg.textContent || '';
        if (!/CoherentPDF|PyMuPDF|qpdf|Ghostscript|TypeError|ReferenceError|undefined|Failed to|Cannot |Error: [A-Za-z]/.test(t)) return;
        msg.textContent = /contrase|password/i.test(t)
          ? 'La contraseña no es correcta. Revísela (mayúsculas, minúsculas y tildes) e intente de nuevo.'
          : 'No se pudo procesar el archivo. Revise que no esté dañado y que sea del tipo que pide esta herramienta, e intente de nuevo. Si sigue igual, escríbanos por WhatsApp al 304 437 5758.';
      };
      new MutationObserver(limpiar).observe(msg, { childList: true, characterData: true, subtree: true });
    }
  }
  // Secciones de relleno en inglés de BentoPDF (preguntas frecuentes y herramientas relacionadas): no se muestran
  document.querySelectorAll('[data-i18n="faq.sectionTitle"], [data-i18n="relatedTools.title"]').forEach((h) => {
    const sec = h.closest('section');
    if (sec) (sec as HTMLElement).style.display = 'none';
  });
  setTimeout(filtrarHerramientasPrueba, 0);
  prepararServiceWorker();
  observarTraduccion(document);
  document.querySelectorAll('[data-static-tool-links]').forEach((e) => e.remove());
  setTimeout(avisoOffice, 0);
  velo().addEventListener('click', (ev) => {
    const t = ev.target as HTMLElement;
    const acc = t.closest('[data-pia]')?.getAttribute('data-pia');
    if (acc === 'cerrar') cerrar();
    else if (acc === 'pagar') pagar();
    else if (acc === 'recuperar') recuperar((document.getElementById('pia-cod') as HTMLInputElement)?.value || '');
  });
  montarBarra();
  montarPortada();
  montarPie();
  {
    const h = document.querySelector('h1, h2') as HTMLElement | null;
    const nombre = h && !document.getElementById('pia-hero') ? (h.textContent || '').trim() : '';
    document.title = nombre && nombre.length < 60 ? nombre + ' · PDF-IA' : 'PDF-IA · Todo lo de PDF en su celular';
  }
  if (PRODUCCION) revisarRegresoBold();
  if (location.hash === '#comprar') setTimeout(() => abrirCompra(), 300);
  if (window.claude && typeof window.claude.use === 'function') {
    window.claude
      .use('downloads')
      .then((d) => (descargasClaude = d as typeof descargasClaude))
      .catch(() => {});
  }
}
/* ---------- Vista de prueba en Claude ----------
   El visor de Claude solo deja abrir la página de entrada; las demás herramientas se abren
   dentro de un marco de la misma app, a pantalla completa. En producción no se usa. */
const VISTA_CLAUDE = /\.claudeusercontent\.com$/i.test(location.hostname);
type Padre = Window & {
  pdfiaAbrir?: (u: string) => void;
  pdfiaCerrar?: () => void;
  pdfiaDescargas?: () => typeof descargasClaude;
};
function padreMismo(): Padre | null {
  try {
    const p = window.parent as Padre;
    if (p !== window && p.location.origin === location.origin && typeof p.pdfiaAbrir === 'function') return p;
  } catch {
    /* otro origen */
  }
  return null;
}
const RAIZ = new URL(import.meta.env.BASE_URL, location.href);
function esInicio(u: URL) {
  const r = u.pathname.slice(RAIZ.pathname.length);
  return r === '' || r === 'index.html';
}
function nombreHerramienta(u: URL) {
  return u.pathname.slice(RAIZ.pathname.length).replace(/\/index\.html$|\/$/, '').replace(/\.html$/, '');
}
function prepararVistaClaude() {
  if (!VISTA_CLAUDE) return;
  const padre = padreMismo();
  if (padre) {
    // Esta página está dentro del marco: si es la portada, se vuelve a la portada de afuera
    if (esInicio(new URL(location.href))) {
      padre.pdfiaCerrar?.();
      return;
    }
    if (!descargasClaude) {
      descargasClaude = {
        save: (o) => {
          const d = padre.pdfiaDescargas?.();
          if (!d) return Promise.reject(new Error('sin descargas'));
          return d.save(o);
        },
      };
    }
  } else {
    // Portada: abre y cierra el marco de herramientas
    const w = window as unknown as Padre;
    let marco: HTMLIFrameElement | null = null;
    w.pdfiaDescargas = () => descargasClaude;
    w.pdfiaAbrir = (url: string) => {
      const u = new URL(url, location.href);
      if (esInicio(u)) return w.pdfiaCerrar!();
      if (!marco) {
        marco = document.createElement('iframe');
        marco.id = 'pia-marco';
        marco.title = 'Herramienta de PDF-IA';
        marco.setAttribute('allow', 'clipboard-write');
        marco.style.cssText = 'position:fixed;inset:0;width:100%;height:100%;border:0;background:#F4F8FB;z-index:2147483000';
        document.body.appendChild(marco);
        document.documentElement.style.overflow = 'hidden';
      }
      marco.src = u.href;
      const n = nombreHerramienta(u);
      if (n && location.hash !== '#' + n) location.hash = n;
    };
    w.pdfiaCerrar = () => {
      if (marco) {
        marco.remove();
        marco = null;
        document.documentElement.style.overflow = '';
      }
      if (location.hash && location.hash !== '#comprar') history.replaceState(null, '', location.pathname + location.search);
      pintarChip();
    };
    const desdeHash = () => {
      const n = location.hash.slice(1);
      if (!n || n === 'comprar') {
        if (marco) w.pdfiaCerrar!();
        return;
      }
      if (!/^[a-z0-9-]+$/.test(n)) return;
      const archivo = n === 'escanear' ? 'escanear/index.html' : n + '.html';
      const lista = (window as unknown as { PDFIA_PAGINAS?: string[] }).PDFIA_PAGINAS;
      if (lista && !lista.includes(archivo)) return;
      const u = new URL(archivo, RAIZ);
      if (!marco || new URL(marco.src).pathname !== u.pathname) w.pdfiaAbrir!(u.href);
    };
    addEventListener('hashchange', desdeHash);
    setTimeout(desdeHash, 0);
  }
  // Enlaces internos a otras páginas: se abren en el marco
  document.addEventListener(
    'click',
    (ev) => {
      if (ev.defaultPrevented || ev.button !== 0 || ev.ctrlKey || ev.metaKey || ev.shiftKey) return;
      const t = ev.target as HTMLElement | null;
      const a = t && t.closest ? (t.closest('a[href]') as HTMLAnchorElement | null) : null;
      if (!a || a.hasAttribute('download') || (a.target && a.target !== '_self')) return;
      const raw = a.getAttribute('href') || '';
      if (!raw || raw.startsWith('#') || /^(mailto|tel|javascript|blob|data):/i.test(raw)) return;
      const u = new URL(a.href, location.href);
      if (u.origin !== location.origin || !u.pathname.startsWith(RAIZ.pathname)) return;
      if (u.pathname === location.pathname) return;
      const destino = padre || (window as unknown as Padre);
      ev.preventDefault();
      ev.stopPropagation();
      if (esInicio(u)) destino.pdfiaCerrar?.();
      else destino.pdfiaAbrir?.(u.href);
    },
    true
  );
}
prepararVistaClaude();

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciar);
else iniciar();
