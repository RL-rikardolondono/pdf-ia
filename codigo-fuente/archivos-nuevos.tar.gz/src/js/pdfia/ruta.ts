/* PDF-IA: convierte rutas "/x" en direcciones dentro de la app, funcione en la raíz
   del dominio (pdf-ia.skynetgenesis.com) o en una subcarpeta (vista de prueba en Claude). */
export function rutaApp(p?: string): string | undefined {
  if (!p || !p.startsWith('/') || p.startsWith('//')) return p;
  try {
    const here = (globalThis as { location?: Location }).location;
    if (!here) return p;
    const enAssets = /\/assets\/[^/]*$/.test(here.pathname);
    const raiz = new URL(enAssets ? '../' : './', here.href);
    // páginas dentro de subcarpetas propias (escanear/)
    return new URL(p.slice(1), raiz).href;
  } catch {
    return p;
  }
}
